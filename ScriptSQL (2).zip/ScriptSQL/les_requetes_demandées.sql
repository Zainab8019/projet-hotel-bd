-- Liste des réservations avec nom client et ville hôtel
SELECT r.Id_Reservation, c.Nom AS Client, h.Ville AS Ville_Hotel
FROM Reservation r
JOIN Client c ON r.Id_Client = c.Id_Client
JOIN Reservation_Chambre rc ON r.Id_Reservation = rc.Id_Reservation
JOIN Chambre ch ON rc.Numero_chambre = ch.Numero
JOIN Hotel h ON ch.Id_Hotel = h.Id_Hotel;


-- Clients habitant à Paris
SELECT * FROM Client WHERE Ville = 'Paris';

-- Nombre de réservations par client
SELECT c.Nom, COUNT(r.Id_Reservation) AS Nombre_Reservations
FROM Client c
LEFT JOIN Reservation r ON c.Id_Client = r.Id_Client
GROUP BY c.Id_Client, c.Nom;

-- Nombre de chambres par type
SELECT tc.Type, COUNT(c.Numero) AS Nombre_Chambres
FROM Type_Chambre tc
LEFT JOIN Chambre c ON tc.Id_Type = c.Id_Type
GROUP BY tc.Id_Type, tc.Type;


-- Chambres non réservées entre deux dates
SELECT c.* 
FROM Chambre c
WHERE c.Numero NOT IN (
    SELECT rc.Numero_chambre
    FROM Reservation r
    JOIN Reservation_Chambre rc ON r.Id_Reservation = rc.Id_Reservation
    WHERE (r.Date_arrivee <= '2025-06-20' AND r.Date_depart >= '2025-06-15')
);